#include <iostream>
using namespace std;

int main() {
    int n, d;
    cin >> n >> d;
    int num_blancs = n - 1; // Nombre d'espais inicials per la primera fila
    int num_digits = 1;     // Nombre de dígits a la primera fila
    // Per cada fila i de la piràmide, de 1 a n
    for (int i = 1; i <= n; ++i) {
        for (int j = 0; j < num_blancs; ++j) cout << ' ';
        for (int k = 0; k < num_digits; ++k) {
            cout << d;
            d = (d + 1) % 10;  // Després del 9 torna al 0.
        }
        cout << endl;
        //actualitza el nombre d'espais i dígits per a la següent fila
        num_blancs--; 
        num_digits += 2; 
    }
}