#include <iostream>
using namespace std;

//Pre: m és un enter no negatiu (m >= 0) 
//Post: retorna true si m és un nombre dos-tres-equilibrat i false altrament. 
bool es_equilibrat(int m) {
     if (m == 0) return true;
     while (m%6 == 0) m = m/6;
     return m%2 != 0 and m%3 != 0;
}

int main() {
    int n;
    cin >> n;
    int comptador = 0;
    int x;
    bool trobat = false; // sabem que n > 0
    // Esquema de cerca: parem quan ja hem trobat n equilibrats consecutius.
    while (not trobat and cin >> x) {
        if (es_equilibrat(x)) {
            ++comptador;
            if (comptador == n) trobat = true;
        }
        else comptador = 0;
    }
    if (trobat) cout << "TRUE" << endl;
    else cout << "FALSE" << endl;
}