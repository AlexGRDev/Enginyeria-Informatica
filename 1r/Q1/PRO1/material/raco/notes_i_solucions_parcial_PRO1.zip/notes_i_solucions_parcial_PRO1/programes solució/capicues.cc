#include <iostream>
using namespace std;

// Pre: x és més gran o igual que 0 i té 8 xifres com a màxim.
// Post: Retorna cert si x és capicua.
//       Retorna fals en cas contrari.
bool es_capicua(int x) {
    int invers = 0;
    int y = x;
    while (y > 0) {
        invers = invers * 10 + y % 10;
        y /= 10;
    }
    return invers == x;
}

int main() {
    int n, m;
    cin >> n >> m;
    // si la m no és vàlida, no cal llegir més nombres, ja que el resultat serà FALSE
    if (m == 0 or m > 8) cout << "FALSE" << endl;
    else {
        // tot nombre de m xifres està entre 10^(m-1) i 10^m - 1, amb l'excepció que si m=1 el mínim és 0.
        int inferior = 1;
        for (int i=0; i < m-1; ++i) inferior *= 10;
        int superior = inferior*10-1;
        if (m == 1) inferior = 0;
        int comptador = 0;
        int x;
        bool trobat = false; 
        // Esquema de cerca: parem quan ja hem trobat n capicues consecutius.
        while (not trobat and cin >> x) {
            if (x>=inferior and x<=superior and es_capicua(x)) {
                ++comptador;
                if (comptador == n) trobat = true;
            }
            else comptador = 0;
        }
        if (trobat) cout << "TRUE" << endl;
        else cout << "FALSE" << endl;
    }
}