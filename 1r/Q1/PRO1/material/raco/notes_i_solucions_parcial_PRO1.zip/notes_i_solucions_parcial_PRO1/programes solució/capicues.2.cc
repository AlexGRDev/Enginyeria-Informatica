#include <iostream>
using namespace std;

// Pre: x >= 0 i té 8 xifres com a màxim. m és un enter >=1 i <=8. 
// Post: Retorna cert si x té exactament m xifres i fals altrament
bool m_xifres(int x, int m) {
    int num=1; // tot nombre (fins i tot el 0) té almenys 1 xifra
    while (x >= 10) {
        x /= 10;
        ++num;
        if (num > m) return false;
    }
    return num == m;
}

// Pre: x és més gran o igual que 0 i té 8 xifres com a màxim.
// Post: Retorna cert si x és capicua.
//       Retorna fals en cas contrari.
bool es_capicua(int x) {
    int invers = 0;
    int y = x;
    while (y > 0) {
        invers = invers * 10 + y % 10;
        y /= 10;
    }
    return invers == x;
}

int main() {
    int n, m;
    cin >> n >> m;
    // si la m no és vàlida, no cal llegir més nombres, ja que el resultat serà FALSE
    if (m == 0 or m > 8) cout << "FALSE" << endl; 
    else {
        int comptador = 0;
        int x;
        bool trobat = false; 
        // Esquema de cerca: parem quan ja hem trobat n capicues consecutius.
        while (not trobat and cin >> x) {
            if (m_xifres(x,m) and es_capicua(x)) {
                ++comptador;
                if (comptador == n) trobat = true;
            }
            else comptador = 0;
        }
        if (trobat) cout << "TRUE" << endl;
        else cout << "FALSE" << endl;
    }
}