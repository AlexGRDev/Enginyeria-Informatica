#include <iostream>
using namespace std;

int main() {
    int n;
    char primer;
    cin >> n >> primer;
    if (n % 2 != 0) {
        cout << "Unable to generate the board because " <<  n << " is odd" << endl;
    }
    else {
        // L'altre color és el contrari del de la primera casella.
        char altre;
        if (primer == 'B') altre = 'N';
        else altre = 'B';
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                // Les caselles amb fila + columna parell tenen el color inicial.
                if ((i + j) % 2 == 0) cout << primer;
                else cout << altre;
            }
            cout << endl;
        }
    }
}