#include <iostream>
using namespace std;

int main() {
    int a1, a2, b1, b2;
    cin >> a1 >> a2 >> b1 >> b2;
    int s1 = a1 + a2;
    int s2 = b1 + b2;
    if (s1 == s2) cout << 0;
    else if (s1 > 7 and s2 > 7) cout << 0;
    else if (s1 > 7) cout << 2;
    else if (s1 < s2  and s2 <= 7) cout << 2;
    else cout << 1;
    cout << endl;
}